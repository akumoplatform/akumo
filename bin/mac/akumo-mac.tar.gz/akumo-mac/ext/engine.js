function cmd(config) {
    let cmd =  new Cmd();
    
    if (config.args){
        cmd.args = config.args;
    }
    if (config.base){
        cmd.base = config.base;
    }

    if (config.wait){
        cmd.wait = config.wait;
    }

    if (config.stop){
        cmd.stop = config.stop;
    }

    if (config.env){
        Object.keys(config.env).forEach(entry => cmd.add(entry.key, entry.value));
    }
    return cmd;

}
/**
 * A factory method to build a process objects.
 * @constructor
 */
function process() {
    return new com.akumo.ext.components.process.Process();

}

/**
 * A factory method to build http objects.
 * @constructor
 */
function http() {
    return new com.akumo.ext.components.HttpClient();
}

/**
 * A factory method to build https objects.
 * @constructor
 */
function https() {
    return new com.akumo.ext.components.HttpsClient();
}

/**
 * Scheduled and parameterize one Task.
 *
 * @param {Object} success a callback to success
 * @param {Object} error a callback to error
 * @param {number} time the time in milliseconds to trigger each one of the task round initiallization
 * @param {Object} process the process to be executed
 *
 */
function schedule(success, error, time, p) {
    stuffExecutor = new com.akumo.ext.components.ScheduleService(time, p);
    stuffExecutor.execute(new JavaAdapter(Packages.com.akumo.ext.components.ScheduleService.Listener, {
        success: function (file) { success(file); },
        error: function (file) { error(file); }

    }));

}

/**
 *
 * Method factory which creating the special no argument Task objects.
 *
 * @returns a new Task object
 */
function watch() {
    return new com.akumo.core.domain.process.Task();

}

/**
 *
 * Initializes one Task object.
 *
 * @param {Object} the function to be executing in a Task.
 */
function task(workParam) {
    stuffExecutor = new com.akumo.ext.components.process.Task();
    stuffExecutor.execute(new JavaAdapter(Packages.com.akumo.ext.components.process.Task.Listener, {
        work: function () { workParam(); }
    }));

}

/**
 * Create a directory watcher.
 *
 * @param {Object} callbackCreate a callback to creating event
 * @param {Object} callbackModify a callback to error event
 * @param {Object} callbackDelete a callback to delete event
 * @param {string} dir the directory to be watched
 *
 */
function watcher(callbackCreate, callbackModify, callbackDelete, dir) {
    stuffExecutor = new com.akumo.ext.components.WatcherFileService(dir);
    stuffExecutor.execute(new JavaAdapter(Packages.com.akumo.ext.components.WatcherFileService.Listener, {
        create: function (file) { callbackCreate(file); },
        modify: function (file) { callbackModify(file); },
        del: function (file) { callbackDelete(file); }
    }));

}
//let akumoMac = '/Users/alissonpedrina/Documents/gitprojects/akumoplatform/java/compiler/tool/akumo-mac';
//var mvn = process().base(akumoMac).args(['mkdir','ext1']).exec();