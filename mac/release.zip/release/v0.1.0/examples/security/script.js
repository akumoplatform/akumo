let context = new Context();
    
context.setProperty('gmail.user', 'akumo');
context.setProperty('gmail.password', 'password');

console.log(`The value stored on gamil.user key: ${context.getProperty('gmail.user')}`);