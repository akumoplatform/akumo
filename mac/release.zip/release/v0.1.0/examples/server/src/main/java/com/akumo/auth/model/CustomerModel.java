package com.akumo.auth.model;

import com.akumo.auth.entity.CustomerEntity;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;

@Data
@NoArgsConstructor
public class CustomerModel {

    @Id
    private int id;
    private String name;

    public CustomerModel(CustomerEntity entity) {
        this.id = entity.getId();
        this.name = entity.getName();
    }
}
