package com.akumo.auth.controller;

import com.akumo.auth.model.ProductModel;
import com.akumo.auth.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController()
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping()
    public ResponseEntity<ProductModel> saveProduct(@RequestBody ProductModel product) {
        return ResponseEntity.ok().body(productService.create(product));

    }

    @GetMapping()
    public ResponseEntity<List<ProductModel>> getProducts() {
        return ResponseEntity.ok(productService.findAll());

    }

}
