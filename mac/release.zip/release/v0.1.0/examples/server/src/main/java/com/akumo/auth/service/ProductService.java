package com.akumo.auth.service;

import com.akumo.auth.entity.ProductEntity;
import com.akumo.auth.model.ProductModel;
import com.akumo.auth.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public ProductModel create(ProductModel productModel) {
        return new ProductModel(productRepository.save(new ProductEntity(productModel)));

    }

    public List<ProductModel> findAll() {
        return productRepository.findAll().stream().map(ProductModel::new).collect(Collectors.toList());
    }
}
