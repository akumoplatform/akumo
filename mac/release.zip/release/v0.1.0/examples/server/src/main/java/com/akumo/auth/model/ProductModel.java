package com.akumo.auth.model;

import com.akumo.auth.entity.ProductEntity;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
public class ProductModel {

    private int id;

    private String description;

    private BigDecimal price;

    public ProductModel(ProductEntity entity) {
        this.id = entity.getId();
        this.description = entity.getDescription();
        this.price = entity.getPrice();

    }
}
