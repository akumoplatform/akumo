package com.akumo.auth.model;

import com.akumo.auth.entity.OrderEntity;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
public class OrderModel {
    private int id;

    private int idProduct;

    private int idCustomer;

    private long quantity;

    private BigDecimal total;

    public OrderModel(OrderEntity order) {
        this.id = order.getId();
        this.idCustomer = order.getIdCustomer();
        this.idProduct = order.getIdProduct();
        this.quantity = order.getQuantity();
        this.total = order.getTotal();

    }
}
