package com.akumo.auth.entity;

import com.akumo.auth.model.OrderModel;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Entity(name = "orders")
@NoArgsConstructor
public class OrderEntity {

    @Id
    @Column(name = "id", columnDefinition = "serial")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "id_product")
    private int idProduct;

    @Column(name = "id_customer")
    private int idCustomer;

    private long quantity;

    private BigDecimal total;

    public OrderEntity(OrderModel order) {
        this.id = order.getId();
        this.idProduct = order.getIdProduct();
        this.idCustomer = order.getIdCustomer();
        this.quantity = order.getQuantity();
        this.total = order.getTotal();

    }

}
