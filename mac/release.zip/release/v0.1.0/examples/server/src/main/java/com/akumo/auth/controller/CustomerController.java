package com.akumo.auth.controller;

import com.akumo.auth.model.CustomerModel;
import com.akumo.auth.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController()
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping()
    public ResponseEntity<CustomerModel> saveCustomer(@RequestBody CustomerModel customer) {
        return ResponseEntity.ok().body(customerService.create(customer));

    }

    @GetMapping()
    public ResponseEntity<List<CustomerModel>> getCustomers() {
        return ResponseEntity.ok(customerService.findAll());

    }
}
