package com.akumo.auth.model;

import com.akumo.auth.entity.PaymentEntity;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PaymentModel {

    private int id;
    private int idOrder;
    private boolean status;

    public PaymentModel(PaymentEntity entity) {
        this.id = entity.getId();
        this.idOrder = entity.getIdOrder();
        this.status = entity.isStatus();

    }

}
