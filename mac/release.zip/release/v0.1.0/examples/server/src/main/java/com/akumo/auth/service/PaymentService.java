package com.akumo.auth.service;

import com.akumo.auth.entity.PaymentEntity;
import com.akumo.auth.model.PaymentModel;
import com.akumo.auth.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    public void doPayment(int idOrder) {
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setIdOrder(idOrder);
        paymentEntity.setStatus(true);
        paymentRepository.save(paymentEntity);

    }

    public List<PaymentModel> findAll() {
        return paymentRepository.findAll().stream().map(PaymentModel::new).collect(Collectors.toList());
    }

}
