package com.akumo.auth.entity;

import com.akumo.auth.model.CustomerModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity(name = "customer")
@NoArgsConstructor
public class CustomerEntity {

    @Id
    @Column(name = "id", columnDefinition = "serial")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;

    public CustomerEntity(CustomerModel customer) {
        this.id = customer.getId();
        this.name = customer.getName();

    }
}
