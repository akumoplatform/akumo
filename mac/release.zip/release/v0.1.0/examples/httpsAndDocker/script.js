Import.rel('/examples/httpsAndDocker/functions.js');
console.time();

let tokenizer = new Tokenizer();

let context = setContext();

let https = setUp();

createData();

let orderResponse = makeAnOrder();
let dockerLsResult = new Process().args(['docker', 'ps']).run(tokenizer.simple);

print(dockerLsResult.rows);

let postgresProcess = buildPostgresProcess();
while (true) {
    if (postgresProcess.run(tokenizer.simple).rows.length >= 4) {
        console.log('payment success...');
        break;

    }

}
console.timeLog();
