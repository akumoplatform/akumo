function setContext() {
    let context = new Context();
    
    context.setProperty('postgres.user', 'postgres');
    context.setProperty('postgres.db', 'postgres');

    context.setProperty('auth.password', 'password');
    context.setProperty('auth.user', 'akumo');

    return context;
}

function setUp() {
    let https = new Https();
    https.root('https://localhost:8081/oauth-server').add({ 'key': 'Content-type', 'value': 'application/json' });
    let result = https.endpoint('/authenticate').post({ "password": context.getProperty("auth.password"), "username": context.getProperty("auth.user") });
    https.add({ 'key': 'Authorization', 'value': 'Bearer ' + JSON.parse(result).token });

    return https;

}

function createData() {
    https.endpoint('/customer').post({ 'name': 'Carla' });
    https.endpoint('/customer').post({ 'name': 'Thomas' });
    https.endpoint('/product').post({ 'description': 'shelf', 'price': 100.34 });
    https.endpoint('/product').post({ 'description': 'bed', 'price': 500 });

}

function buildPostgresProcess() {
    let dockerContainer = dockerLsResult.rows.filter(row => row.includes('postgres-container'));
    let fromPayment = `select * from payment where id_order = ${orderResponse.id};`;
    let postgresCommand = `docker exec ${dockerContainer[0][0]} psql -U '${context.getProperty("postgres.user")}' -d postgres -c '${fromPayment}'`;
    let postgresSqlArgs = ['bash', '-c', postgresCommand];
    
    return new Process().args(postgresSqlArgs).template({ 'separator': /\|/ });

}

function makeAnOrder() {
    let customers = JSON.parse(https.endpoint('/customer').get());
    let products = JSON.parse(https.endpoint('/product').get());
    let order = { "idCustomer": customers[0].id, "idProduct": products[0].id, "quantity": 10, "total": (products[0].price * 10) }
    
    return JSON.parse(https.endpoint('/order').post(order));

}