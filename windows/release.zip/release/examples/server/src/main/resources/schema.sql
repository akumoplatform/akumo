--------------- Postgres -----------
create table if not exists orders (
    id SERIAL PRIMARY KEY,
    id_product VARCHAR(255),
    id_costumer VARCHAR(255),
    quantity numeric,
    total float(8)
);

create table if not exists payment (
    id SERIAL PRIMARY KEY,
    id_order VARCHAR(255),
    status boolean
);

create table if not exists product (
    id SERIAL PRIMARY KEY,
    description VARCHAR(255),
    price float(8)
);

create table if not exists customer (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255)
);