package com.akumo.auth.entity;

import com.akumo.auth.model.ProductModel;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Entity(name = "product")
@NoArgsConstructor
public class ProductEntity {

    @Id
    @Column(name = "id", columnDefinition = "serial")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String description;

    private BigDecimal price;

    public ProductEntity(ProductModel productModel) {
        this.id = productModel.getId();
        this.description = productModel.getDescription();
        this.price = productModel.getPrice();
    }
}
