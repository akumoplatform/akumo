package com.akumo.auth.service;

import com.akumo.auth.entity.OrderEntity;
import com.akumo.auth.model.OrderModel;
import com.akumo.auth.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private PaymentService paymentService;

    public OrderModel create(OrderModel order) throws InterruptedException {
        OrderModel orderSaved = new OrderModel(this.orderRepository.save(new OrderEntity(order)));
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                paymentService.doPayment(orderSaved.getId());

            }
        });
        thread.setDaemon(true);
        thread.start();


        return orderSaved;
    }

    public List<OrderModel> findAll() {
        return orderRepository.findAll().stream().map(OrderModel::new).collect(Collectors.toList());
    }
}
