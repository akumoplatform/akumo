package com.akumo.auth.controller;

import com.akumo.auth.model.OrderModel;
import com.akumo.auth.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController()
@RequestMapping("/order")
public class OrdersController {
    @Autowired
    private OrderService orderService;

    @PostMapping()
    public ResponseEntity<OrderModel> saveOrder(@RequestBody OrderModel order) throws InterruptedException {
        return ResponseEntity.ok().body(orderService.create(order));

    }

    @GetMapping()
    public ResponseEntity<List<OrderModel>> getOrders() {
        return ResponseEntity.ok(orderService.findAll());

    }
}
