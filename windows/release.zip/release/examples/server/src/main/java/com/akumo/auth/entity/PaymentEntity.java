package com.akumo.auth.entity;

import lombok.Data;

@Data
@Entity(name = "payment")
public class PaymentEntity {

    @Id
    @Column(name = "id", columnDefinition = "serial")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "id_order")
    private int idOrder;

    private boolean status;

}
