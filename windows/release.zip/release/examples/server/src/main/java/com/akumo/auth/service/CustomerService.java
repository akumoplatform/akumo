package com.akumo.auth.service;

import com.akumo.auth.entity.CustomerEntity;
import com.akumo.auth.model.CustomerModel;
import com.akumo.auth.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public CustomerModel create(CustomerModel customer) {
        return new CustomerModel(this.customerRepository.save(new CustomerEntity(customer)));

    }

    public List<CustomerModel> findAll() {
        return customerRepository.findAll().stream().map(CustomerModel::new).collect(Collectors.toList());

    }
}
